var searchData=
[
  ['r_2945',['r',['../glad_8h.html#abe08814c2f72843fde4d8df41440d5a0',1,'glad.h']]],
  ['range_2946',['range',['../glad_8h.html#a73b00379db2c7ac5e30a3aa2954a50ee',1,'glad.h']]],
  ['readoffset_2947',['readOffset',['../glad_8h.html#a11d94888acbeffbdc587155c0576417d',1,'glad.h']]],
  ['rect_2948',['rect',['../class_ball.html#ad4f294b00d5bab91244f192e01b3082f',1,'Ball::rect()'],['../class_brick.html#ab4c6e2bfb3b0c09cc8fefa8372632c4c',1,'Brick::rect()'],['../class_label.html#ab640c849f3f254dd851186cd5766864e',1,'Label::rect()'],['../class_paddle.html#a3ba553ef3fbf45b23f2e2d866838e36b',1,'Paddle::rect()']]],
  ['ref_2949',['ref',['../glad_8h.html#a083de4c8e32ad3d9059245f26be721de',1,'glad.h']]],
  ['renderbuffer_2950',['renderbuffer',['../glad_8h.html#a065ecbf0bfaaefcafcc191ff33481bec',1,'glad.h']]],
  ['renderbuffers_2951',['renderbuffers',['../glad_8h.html#aa17b802a0d8dde64cb30f5d887be5a22',1,'glad.h']]],
  ['renderbuffertarget_2952',['renderbuffertarget',['../glad_8h.html#ad4ca76f1378b4a8be4243761c8df68e6',1,'glad.h']]],
  ['renderer_2953',['renderer',['../class_label.html#a5e43f87f0c58333dda3125affe63c4f7',1,'Label']]],
  ['resetgame_2954',['ResetGame',['../lab_8cpp.html#a2200c9a3564da59c1160338587ecb034ada184aa15ffc80bd0d5df1a1bd74f355',1,'lab.cpp']]],
  ['residences_2955',['residences',['../glad_8h.html#a0058cff9dc7ae56534241571ecd631b3',1,'glad.h']]],
  ['right_2956',['right',['../glad_8h.html#ab412e67df941b4600c352b0b9e76d2ee',1,'glad.h']]],
  ['right_2957',['Right',['../_ball_8hpp.html#aa884075f403706dceea29a61771a0d44a92b09c7c48c520c3c55e497875da437c',1,'Ball.hpp']]]
];
