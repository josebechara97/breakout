var searchData=
[
  ['y_3037',['y',['../class_vec2.html#a30543787e62f6d915543cf1dfb04c094',1,'Vec2::y()'],['../class_vector3.html#a86eb35a9fa2d5a49e7fad66a35fa9c13',1,'Vector3::y()'],['../glad_8h.html#a66ddd433d2cacfe27f5906b7e86faeed',1,'y():&#160;glad.h']]],
  ['y1_3038',['y1',['../glad_8h.html#a48340161068d267815ac3131e9d03def',1,'glad.h']]],
  ['y2_3039',['y2',['../glad_8h.html#af7158b5d27f7a6aa4ab9973fcc3a5c20',1,'glad.h']]],
  ['yfactor_3040',['yfactor',['../glad_8h.html#a35c8ad7bbcca23e97ab9dadfbda4c0c9',1,'glad.h']]],
  ['ymove_3041',['ymove',['../glad_8h.html#ac69eb3ea93058abe33dbca40a84234ed',1,'glad.h']]],
  ['yoffset_3042',['yoffset',['../glad_8h.html#a76dfb6803dcff61037ba688b7f4242b8',1,'glad.h']]],
  ['yorig_3043',['yorig',['../glad_8h.html#a12efb8d14365059e7a8c24a87440d5d7',1,'glad.h']]],
  ['youlose_3044',['youLose',['../lab_8cpp.html#a480540e3ac51984139331d8173df9ff4a286948f8be8d3f0ee00efff1bff837fb',1,'lab.cpp']]],
  ['youwin_3045',['youWin',['../lab_8cpp.html#a480540e3ac51984139331d8173df9ff4ae992da453db3443eff0578041dc8d511',1,'lab.cpp']]]
];
