var searchData=
[
  ['font_22',['font',['../class_label.html#a89e9b1ebaede94e0076108cff3907e3b',1,'Label']]]
];
