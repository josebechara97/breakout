var searchData=
[
  ['setmessage_50',['SetMessage',['../class_label.html#abdb3c197a3de0b66a39d011aa2735b2d',1,'Label']]],
  ['setscore_51',['SetScore',['../class_label.html#abc5987668fd6e08f5f72a4098988a682',1,'Label']]],
  ['startgame_52',['StartGame',['../lab_8cpp.html#a2200c9a3564da59c1160338587ecb034a995bdb14b736d74c60324957b982c43f',1,'lab.cpp']]],
  ['state_53',['state',['../class_ball.html#abb126b9e9bbee1f9952578480efb73c8',1,'Ball::state()'],['../class_brick.html#a0c915da128e0deb1788fbbecd7516452',1,'Brick::state()']]],
  ['strings_54',['Strings',['../lab_8cpp.html#a480540e3ac51984139331d8173df9ff4',1,'lab.cpp']]],
  ['surface_55',['surface',['../class_label.html#a0bf7af0a684b5a2e569d99572cc72cc2',1,'Label']]]
];
