var searchData=
[
  ['update_60',['Update',['../class_ball.html#a791a8547e5a882d05c1acc4cbfcee86b',1,'Ball::Update()'],['../class_brick.html#a41cdd3ca7d4913c32997f207ac96d72d',1,'Brick::Update()'],['../class_paddle.html#a2e0edce0c38b90a057c373cebaadf160',1,'Paddle::Update()']]]
];
