var searchData=
[
  ['vec2_61',['Vec2',['../class_vec2.html',1,'Vec2'],['../class_vec2.html#a76080feed7005893ecc634f903cfbae0',1,'Vec2::Vec2()'],['../class_vec2.html#a6256fecebf5a43b14d5d5341c58cfdc4',1,'Vec2::Vec2(float x, float y)']]],
  ['velocity_62',['velocity',['../class_ball.html#ab5da7c8a1d90ecfb433a917071d38bd7',1,'Ball::velocity()'],['../class_brick.html#a9b53935ed9c85a4b3d42b531c6aa8a54',1,'Brick::velocity()'],['../class_paddle.html#a272bc6a57f577cca115ee892bd029658',1,'Paddle::velocity()']]]
];
