var searchData=
[
  ['window_5fheight_63',['WINDOW_HEIGHT',['../_ball_8hpp.html#ab76d138fa589df9a65fc05eb3bd56073',1,'Ball.hpp']]],
  ['window_5fwidth_64',['WINDOW_WIDTH',['../_ball_8hpp.html#a5e6ce0dd58078611570510dc4b8d81f3',1,'Ball.hpp']]]
];
