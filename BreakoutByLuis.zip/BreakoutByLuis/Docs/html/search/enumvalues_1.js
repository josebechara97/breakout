var searchData=
[
  ['left_133',['Left',['../_ball_8hpp.html#aa884075f403706dceea29a61771a0d44a945d5e233cf7d6240f6b783b36a374ff',1,'Ball.hpp']]]
];
