var searchData=
[
  ['middle_134',['Middle',['../_ball_8hpp.html#aa884075f403706dceea29a61771a0d44ab1ca34f82e83c52b010f86955f264e05',1,'Ball.hpp']]]
];
