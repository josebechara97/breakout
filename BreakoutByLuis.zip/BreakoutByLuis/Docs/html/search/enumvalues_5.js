var searchData=
[
  ['resetgame_139',['ResetGame',['../lab_8cpp.html#a2200c9a3564da59c1160338587ecb034ada184aa15ffc80bd0d5df1a1bd74f355',1,'lab.cpp']]],
  ['right_140',['Right',['../_ball_8hpp.html#aa884075f403706dceea29a61771a0d44a92b09c7c48c520c3c55e497875da437c',1,'Ball.hpp']]]
];
