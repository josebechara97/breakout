var searchData=
[
  ['label_92',['Label',['../class_label.html#af013098090df96a10162bfb85bd46b25',1,'Label::Label(Vec2 position, SDL_Renderer *renderer, TTF_Font *font)'],['../class_label.html#a5d02f18a4f9ea12b9ed9e21375e501a2',1,'Label::Label(Vec2 position, SDL_Renderer *renderer, TTF_Font *font, const char *message)']]]
];
