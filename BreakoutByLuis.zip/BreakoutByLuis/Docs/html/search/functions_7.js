var searchData=
[
  ['setmessage_98',['SetMessage',['../class_label.html#abdb3c197a3de0b66a39d011aa2735b2d',1,'Label']]],
  ['setscore_99',['SetScore',['../class_label.html#abc5987668fd6e08f5f72a4098988a682',1,'Label']]]
];
