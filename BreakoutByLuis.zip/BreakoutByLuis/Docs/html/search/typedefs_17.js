var searchData=
[
  ['x_4097',['x',['../glad_8h.html#a92d0386e5c19fb81ea88c9f99644ab1d',1,'glad.h']]],
  ['x2_4098',['x2',['../glad_8h.html#ad2cea6eadb01f017f0d57e7edf0ce988',1,'glad.h']]],
  ['xmove_4099',['xmove',['../glad_8h.html#a660a4b1a65b57e4184add3d2557c6bf0',1,'glad.h']]],
  ['xoffset_4100',['xoffset',['../glad_8h.html#ac20a0ffebf4c476650fcfa0633066f0e',1,'glad.h']]],
  ['xorig_4101',['xorig',['../glad_8h.html#aab7afbca05528ca0c22440fe04f81f54',1,'glad.h']]]
];
