var searchData=
[
  ['name_4010',['name',['../glad_8h.html#a5c4947d4516dd7cfa3505ce3a648a4ef',1,'glad.h']]],
  ['normalized_4011',['normalized',['../glad_8h.html#a66b8b19bdb6fb36da1c1baacf84f6750',1,'glad.h']]],
  ['ny_4012',['ny',['../glad_8h.html#a0fced2824d94c0fd138a58727a89adfc',1,'glad.h']]],
  ['nz_4013',['nz',['../glad_8h.html#ab5d2115402ae81dc9b0967e1cfb9229a',1,'glad.h']]]
];
