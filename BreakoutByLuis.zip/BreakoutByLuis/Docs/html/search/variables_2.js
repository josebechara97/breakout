var searchData=
[
  ['left_5foffset_109',['LEFT_OFFSET',['../lab_8cpp.html#ac746391726a9d3d7f246f336148d8590',1,'lab.cpp']]]
];
