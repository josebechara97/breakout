var searchData=
[
  ['state_118',['state',['../class_ball.html#abb126b9e9bbee1f9952578480efb73c8',1,'Ball::state()'],['../class_brick.html#a0c915da128e0deb1788fbbecd7516452',1,'Brick::state()']]],
  ['surface_119',['surface',['../class_label.html#a0bf7af0a684b5a2e569d99572cc72cc2',1,'Label']]]
];
